﻿using System;
using System.Collections.Generic;

/// <summary>
/// 
/// </summary>
/// <author>
/// Brian Gorishek
/// </author>

namespace Problem1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter your favorite sports and the system will output the ones containing 'ball' in their name.");

            string answer = "";
            List<string> sports = new List<string>();

            do
            {
                Console.WriteLine("Enter a sport:");
                answer = Console.ReadLine();
                sports.Add(answer);

                Console.WriteLine("Would you like to enter another sport?");
                answer = Console.ReadLine();

            } while (answer.ToLower()[0] == 'y');

            Console.WriteLine("You entered the following sports containing the word 'ball':");

            SportsWithBallInTheName(sports);

            //foreach (var sport in sports)
            //{
            //    if (sport.ToLower().Contains("ball"))
            //    {
            //        Console.WriteLine(sport);
            //    }
            //}

        }


        static void SportsWithBallInTheName(List<string> list)
        {
            foreach (string item in list)
            {
                if (item.ToLower().Contains("ball"))
                {
                    Console.WriteLine(item);
                }
            }
            
            return;
        }
    }
}
