﻿using System;
using System.IO;

/// <summary>
/// 
/// </summary>
/// <author>
/// Brian Gorishek
/// </author>

namespace Problem2
{
    class Program
    {
        static void Main(string[] args)
        {

            string[] lines = File.ReadAllLines("event_registration.csv");

            foreach (var line in lines)
            {
                Console.WriteLine(line);
            }

        }
    }
}
