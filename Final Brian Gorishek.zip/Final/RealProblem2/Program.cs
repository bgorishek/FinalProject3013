﻿using System;
using System.Collections.Generic;
using System.IO;

namespace RealProblem2
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] lines = File.ReadAllLines("event_registration.csv");

            //foreach (var line in lines)
            //{
            //    Console.WriteLine(line);
            //}

            List<Registration> employees = new List<Registration>();

            int idAns = 0;
            string firstAns = "";
            string lastAns = "";
            string compAns = "";
            string emailAns = "";
            string titleAns = "";
            string sizeAns = "";
            string passAns = "";

            string answer = "";

            Registration active = new Registration();

            foreach (var line in lines)
            {

                if (line == lines[0])
                {
                    Console.WriteLine("Welcome. Please enter the shirt size you would like to count: (XS/S/M/L/XL)");
                }
                else
                {
                    string[] words = line.Split(",");

                    idAns = Convert.ToInt32(words[0]);
                    firstAns = words[1];
                    lastAns = words[2];
                    compAns = words[3];
                    emailAns = words[4];
                    titleAns = words[5];
                    sizeAns = words[6];
                    passAns = words[7];

                    active = new Registration(idAns, firstAns, lastAns, compAns, emailAns, titleAns, sizeAns, passAns);
                    employees.Add(active);
                }

            }

            answer = Console.ReadLine();
            int count = 0;

            if (answer.ToLower() == "xs")
            {
                foreach (Registration emp in employees)
                {
                    if (emp.ShirtSize.ToLower() == "xs")
                    {
                        count++;
                    }
                }
            }
            else if (answer.ToLower() == "s")
            {
                foreach (Registration emp in employees)
                {
                    if (emp.ShirtSize.ToLower() == "s")
                    {
                        count++;
                    }
                }
            }
            else if (answer.ToLower() == "m")
            {
                foreach (Registration emp in employees)
                {
                    if (emp.ShirtSize.ToLower() == "m")
                    {
                        count++;
                    }
                }
            }
            else if (answer.ToLower() == "l")
            {
                foreach (Registration emp in employees)
                {
                    if (emp.ShirtSize.ToLower() == "l")
                    {
                        count++;
                    }
                }
            }
            else if (answer.ToLower() == "xl")
            {
                foreach (Registration emp in employees)
                {
                    if (emp.ShirtSize.ToLower() == "xl")
                    {
                        count++;
                    }
                }
            }
            else
            {
                Console.WriteLine("ERROR");
            }

            Console.WriteLine("There are " + count + " registrations with that shirt size");

            Console.WriteLine("Press ENTER to proceed to users needing password updates");

            answer = Console.ReadLine();

            Console.WriteLine("\n\nThe Following users have passwords less than 7 characters in length and have been flagged to update their passwords:");

            foreach (Registration emp1 in employees)
            {
                if (emp1.Password.Length <= 7)
                {
                    Console.WriteLine("\nUserID: " + emp1.EmployeeID + "\t " + emp1.LastName + ", " + emp1.FirstName);
                }
            }

        }
    }
}
