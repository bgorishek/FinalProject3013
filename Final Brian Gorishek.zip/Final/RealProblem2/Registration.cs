﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RealProblem2
{
    public class Registration
    {

        public int EmployeeID { get; set; }

        public string FirstName { get; set; }

        public string LastName { get; set; }

        public string Company { get; set; }

        public string Email { get; set; }

        public string Title { get; set; }

        public string ShirtSize { get; set; }

        public string Password { get; set; }


        public Registration()
        {
            EmployeeID = 0;
            FirstName = "";
            LastName = "";
            Company = "";
            Email = "";
            Title = "";
            ShirtSize = "";
            Password = "";

        }

        public Registration(int id, string first, string last, string company, string email, string title, string size, string password)
        {
            EmployeeID = id;
            FirstName = first;
            LastName = last;
            Company = company;
            Email = email;
            Title = title;
            ShirtSize = size;
            Password = password;
        }


        public override string ToString()
        {
            return base.ToString();
        }

    }





}
